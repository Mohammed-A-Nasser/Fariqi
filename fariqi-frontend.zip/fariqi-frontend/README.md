# فريقي — نظام إدارة التكليفات 🏥

نظام إدارة المكتب الفني والتكليفات لمستشفى القنطرة شرق.

## 📁 هيكل المشروع

```
fariqi-frontend/
├── index.html              → تسجيل الدخول
├── dashboard.html          → لوحة التحكم
├── tasks.html              → التكليفات
├── task-detail.html        → تفاصيل التكليف
├── users.html              → المستخدمون
├── departments.html        → الإدارات
├── reports.html            → التقارير
├── department-report.html  → تقرير الإدارة (PDF)
├── notifications.html      → الإشعارات
├── settings.html           → الإعدادات
├── css/
│   └── style.css           → التنسيقات
└── js/
    └── script.js           → منطق التطبيق + Firebase
```

## 🚀 التشغيل

افتح `index.html` في المتصفح مباشرةً، أو استخدم Live Server في VS Code.

**بيانات الدخول التجريبية:**
- admin / admin123
- ahmed / ahmed123

## ⚙️ إعداد Firebase

في ملف `js/script.js`، استبدل القيم في `firebaseConfig` ببيانات مشروعك من [Firebase Console](https://console.firebase.google.com).

## 🛠️ التقنيات المستخدمة

- HTML5 / CSS3
- Bootstrap 5.3 (RTL)
- Font Awesome 6
- Firebase Firestore

## 🏥 المشروع

مستشفى القنطرة شرق — المكتب الفني
