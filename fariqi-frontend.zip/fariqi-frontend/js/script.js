// ============================================
// 🔥 تهيئة Firebase - نظام فريقي
// ============================================

// 🔑 استبدل هذا الكود بالبيانات التي نسختها من Firebase Console
const firebaseConfig = {
    apiKey: "YOUR_API_KEY",
    authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
    projectId: "YOUR_PROJECT_ID",
    storageBucket: "YOUR_PROJECT_ID.appspot.com",
    messagingSenderId: "YOUR_SENDER_ID",
    appId: "YOUR_APP_ID"
};

// تهيئة Firebase
firebase.initializeApp(firebaseConfig);
const db = firebase.firestore();

// ============================================
// 📦 دوال إدارة المستخدمين (CRUD) مع Firebase
// ============================================

// 1. إضافة مستخدم جديد (Create)
async function addUserToFirebase(userData) {
    try {
        const docRef = await db.collection('users').add(userData);
        console.log("✅ تمت إضافة المستخدم بنجاح، ID: ", docRef.id);
        return { success: true, id: docRef.id };
    } catch (error) {
        console.error("❌ خطأ في الإضافة: ", error);
        return { success: false, error: error.message };
    }
}

// 2. جلب جميع المستخدمين (Read)
async function getUsersFromFirebase() {
    try {
        const querySnapshot = await db.collection('users').orderBy('createdAt', 'desc').get();
        const users = [];
        querySnapshot.forEach((doc) => {
            users.push({ id: doc.id, ...doc.data() });
        });
        return { success: true, data: users };
    } catch (error) {
        console.error("❌ خطأ في الجلب: ", error);
        return { success: false, error: error.message };
    }
}

// 3. تحديث مستخدم (Update)
async function updateUserInFirebase(userId, updatedData) {
    try {
        await db.collection('users').doc(userId).update(updatedData);
        console.log(`✅ تم تحديث المستخدم ${userId} بنجاح`);
        return { success: true };
    } catch (error) {
        console.error("❌ خطأ في التحديث: ", error);
        return { success: false, error: error.message };
    }
}

// 4. حذف مستخدم (Delete)
async function deleteUserFromFirebase(userId) {
    try {
        await db.collection('users').doc(userId).delete();
        console.log(`✅ تم حذف المستخدم ${userId} بنجاح`);
        return { success: true };
    } catch (error) {
        console.error("❌ خطأ في الحذف: ", error);
        return { success: false, error: error.message };
    }
}

// ============================================
// 🖥️ دوال عرض المستخدمين في الواجهة
// ============================================

// تحميل المستخدمين في الجدول
async function loadUsersTable() {
    const tableBody = document.getElementById('usersBody');
    if (!tableBody) return;

    // عرض رسالة تحميل
    tableBody.innerHTML = `<tr><td colspan="7" class="text-center">⏳ جاري تحميل المستخدمين...</td></tr>`;

    const result = await getUsersFromFirebase();
    
    if (!result.success) {
        tableBody.innerHTML = `<tr><td colspan="7" class="text-center text-danger">❌ خطأ في التحميل: ${result.error}</td></tr>`;
        return;
    }

    if (result.data.length === 0) {
        tableBody.innerHTML = `<tr><td colspan="7" class="text-center">📭 لا يوجد مستخدمون حتى الآن</td></tr>`;
        updateStats(0, 0, 0, 0);
        return;
    }

    // عرض المستخدمين في الجدول
    let html = '';
    let total = 0, active = 0, inactive = 0, suspended = 0;
    
    result.data.forEach((user, index) => {
        total++;
        let statusBadge = '';
        let statusText = user.status || 'نشط';
        
        if (statusText === 'نشط') {
            statusBadge = '<span class="badge bg-success">نشط</span>';
            active++;
        } else if (statusText === 'غير نشط') {
            statusBadge = '<span class="badge bg-warning text-dark">غير نشط</span>';
            inactive++;
        } else {
            statusBadge = '<span class="badge bg-danger">معلق</span>';
            suspended++;
        }
        
        html += `
            <tr>
                <td>${index + 1}</td>
                <td><span class="fw-semibold">${user.fullName || 'غير محدد'}</span></td>
                <td>${user.email || 'غير محدد'}</td>
                <td>${user.department || 'غير محدد'}</td>
                <td>${user.role || 'غير محدد'}</td>
                <td>${statusBadge}</td>
                <td>
                    <button class="btn btn-sm btn-outline-teal" onclick="editUser('${user.id}')">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="btn btn-sm btn-outline-danger" onclick="deleteUser('${user.id}')">
                        <i class="fas fa-trash"></i>
                    </button>
                </td>
            </tr>
        `;
    });
    
    tableBody.innerHTML = html;
    updateStats(total, active, inactive, suspended);
}

// تحديث الإحصائيات
function updateStats(total, active, inactive, suspended) {
    const totalEl = document.getElementById('totalUsers');
    const activeEl = document.getElementById('activeUsers');
    const inactiveEl = document.getElementById('inactiveUsers');
    const suspendedEl = document.getElementById('suspendedUsers');
    
    if (totalEl) totalEl.textContent = total;
    if (activeEl) activeEl.textContent = active;
    if (inactiveEl) inactiveEl.textContent = inactive;
    if (suspendedEl) suspendedEl.textContent = suspended;
}

// ============================================
// 🗑️ دوال الحذف والتعديل
// ============================================

// حذف مستخدم
window.deleteUser = async function(userId) {
    if (!confirm('⚠️ هل أنت متأكد من حذف هذا المستخدم؟')) return;
    
    const result = await deleteUserFromFirebase(userId);
    if (result.success) {
        alert('✅ تم حذف المستخدم بنجاح');
        loadUsersTable();
    } else {
        alert('❌ حدث خطأ: ' + result.error);
    }
};

// تعديل مستخدم (سيتم تفعيله لاحقاً)
window.editUser = function(userId) {
    alert('✏️ سيتم تفعيل تعديل المستخدم قريباً');
};

// ============================================
// ➕ إضافة مستخدم جديد
// ============================================

document.addEventListener('DOMContentLoaded', function() {
    
    // ===== تحميل المستخدمين عند فتح الصفحة =====
    if (document.getElementById('usersBody')) {
        loadUsersTable();
    }

    // ===== إضافة مستخدم جديد =====
    const saveUserBtn = document.getElementById('saveUserBtn');
    if (saveUserBtn) {
        saveUserBtn.addEventListener('click', async function() {
            // جلب البيانات من النموذج
            const fullName = document.getElementById('userFullName').value.trim();
            const username = document.getElementById('userUsername').value.trim();
            const email = document.getElementById('userEmail').value.trim();
            const phone = document.getElementById('userPhone').value.trim();
            const department = document.getElementById('userDepartment').value;
            const role = document.getElementById('userRole').value;
            const password = document.getElementById('userPassword').value;
            const confirmPassword = document.getElementById('userConfirmPassword').value;

            // التحقق من الحقول المطلوبة
            if (!fullName || !username || !email || !department || !role || !password) {
                alert('❌ يرجى ملء جميع الحقول المطلوبة');
                return;
            }

            if (password !== confirmPassword) {
                alert('❌ كلمة المرور وتأكيدها غير متطابقين');
                return;
            }

            if (password.length < 6) {
                alert('❌ كلمة المرور يجب أن تكون 6 أحرف على الأقل');
                return;
            }

            // تحضير البيانات
            const userData = {
                fullName: fullName,
                username: username,
                email: email,
                phone: phone || '',
                department: department,
                role: role,
                status: 'نشط',
                createdAt: new Date().toISOString()
            };

            // إضافة إلى Firebase
            const result = await addUserToFirebase(userData);
            
            if (result.success) {
                alert('✅ تم إضافة المستخدم بنجاح!');
                // إغلاق المودال
                const modal = bootstrap.Modal.getInstance(document.getElementById('newUserModal'));
                if (modal) modal.hide();
                // تنظيف النموذج
                document.getElementById('newUserForm').reset();
                // تحديث جدول المستخدمين
                loadUsersTable();
            } else {
                alert('❌ حدث خطأ: ' + result.error);
            }
        });
    }

    // ==========================================
    // 1. معالجة نموذج تسجيل الدخول
    // ==========================================
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const username = document.getElementById('username').value.trim();
            const password = document.getElementById('password').value.trim();

            if (username === 'admin' && password === '123') {
                window.location.href = 'dashboard.html';
            } else {
                const errorDiv = document.getElementById('loginError');
                errorDiv.classList.remove('d-none');
                setTimeout(() => {
                    errorDiv.classList.add('d-none');
                }, 3000);
            }
        });
    }

    // ==========================================
    // 2. إظهار/إخفاء كلمة المرور
    // ==========================================
    const togglePasswordBtn = document.getElementById('togglePassword');
    if (togglePasswordBtn) {
        togglePasswordBtn.addEventListener('click', function() {
            const passwordInput = document.getElementById('password');
            const icon = this.querySelector('i');
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                icon.className = 'fas fa-eye-slash';
            } else {
                passwordInput.type = 'password';
                icon.className = 'fas fa-eye';
            }
        });
    }

    // ==========================================
    // 3. تبديل القائمة الجانبية (للجوال)
    // ==========================================
    const sidebarToggle = document.getElementById('sidebarToggle');
    const sidebar = document.getElementById('sidebar');
    if (sidebarToggle && sidebar) {
        sidebarToggle.addEventListener('click', function() {
            sidebar.classList.toggle('open');
        });
    }

    document.addEventListener('click', function(e) {
        if (window.innerWidth <= 768) {
            if (sidebar && !sidebar.contains(e.target) && e.target !== sidebarToggle) {
                sidebar.classList.remove('open');
            }
        }
    });

    // ==========================================
    // 4. تفعيل الروابط في القائمة الجانبية
    // ==========================================
    const navLinks = document.querySelectorAll('.sidebar .nav-link:not(.logout-btn)');
    navLinks.forEach(link => {
        link.addEventListener('click', function() {
            navLinks.forEach(l => l.classList.remove('active'));
            this.classList.add('active');
        });
    });

    // ==========================================
    // 5. عرض التاريخ الحالي
    // ==========================================
    const dateElement = document.getElementById('currentDate');
    if (dateElement) {
        const now = new Date();
        const options = { year: 'numeric', month: 'long', day: 'numeric' };
        dateElement.textContent = now.toLocaleDateString('ar-EG', options);
    }

    // ==========================================
    // 6. مخطط دائري - توزيع المهام (Chart.js)
    // ==========================================
    const pieChartCanvas = document.getElementById('taskPieChart');
    if (pieChartCanvas && typeof Chart !== 'undefined') {
        new Chart(pieChartCanvas, {
            type: 'doughnut',
            data: {
                labels: ['مكتملة (14)', 'قيد التنفيذ (8)', 'متأخرة (2)'],
                datasets: [{
                    data: [14, 8, 2],
                    backgroundColor: ['#198754', '#ffc107', '#dc3545'],
                    borderWidth: 2,
                    borderColor: '#fff'
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: { font: { size: 13 } }
                    }
                }
            }
        });
    }

    // ==========================================
    // 7. تحميل بيانات التكليفات الوهمية
    // ==========================================
    const tasksBody = document.getElementById('tasksBody');
    if (tasksBody) {
        const mockTasks = [
            { id: 25, title: 'تحديث سياسات الجودة', department: 'الجودة', assignee: 'د. سارة', due: '2026-06-21', status: 'قيد التنفيذ', priority: 'حرجة' },
            { id: 18, title: 'تقرير المكافحة الشهري', department: 'مكافحة العدوى', assignee: 'أ. خالد', due: '2026-06-16', status: 'متأخرة', priority: 'عالية' },
            { id: 12, title: 'جرد الأدوية الفصلية', department: 'الصيدلة', assignee: 'ص. نادر', due: '2026-06-10', status: 'مكتملة', priority: 'متوسطة' },
            { id: 8, title: 'تحديث سجلات الموظفين', department: 'الموارد البشرية', assignee: 'م. يوسف', due: '2026-06-25', status: 'قيد التنفيذ', priority: 'متوسطة' },
            { id: 5, title: 'صيانة أجهزة الأشعة', department: 'الهندسة', assignee: 'م. كريم', due: '2026-06-28', status: 'معلقة', priority: 'عالية' },
        ];

        function getStatusBadge(status) {
            const badges = {
                'قيد التنفيذ': '<span class="badge bg-warning text-dark">قيد التنفيذ</span>',
                'مكتملة': '<span class="badge bg-success">مكتملة</span>',
                'متأخرة': '<span class="badge bg-danger">متأخرة</span>',
                'معلقة': '<span class="badge bg-secondary">معلقة</span>'
            };
            return badges[status] || `<span class="badge bg-secondary">${status}</span>`;
        }

        function renderTasks(tasks) {
            tasksBody.innerHTML = tasks.map(task => `
                <tr>
                    <td><span class="fw-semibold">#${task.id}</span></td>
                    <td>${task.title}</td>
                    <td>${task.department}</td>
                    <td>${task.assignee}</td>
                    <td>${task.due}</td>
                    <td>${getStatusBadge(task.status)}</td>
                    <td>
                        <a href="task-detail.html" class="btn btn-sm btn-outline-teal">
                            <i class="fas fa-eye"></i>
                        </a>
                        <button class="btn btn-sm btn-outline-success">
                            <i class="fas fa-edit"></i>
                        </button>
                    </td>
                </tr>
            `).join('');
        }

        renderTasks(mockTasks);

        // ===== البحث والفلترة =====
        const searchInput = document.getElementById('searchTask');
        const filterDept = document.getElementById('filterDepartment');
        const filterStatus = document.getElementById('filterStatus');
        const applyBtn = document.getElementById('applyFilters');

        function filterTasks() {
            const searchTerm = searchInput ? searchInput.value.toLowerCase() : '';
            const deptFilter = filterDept ? filterDept.value : '';
            const statusFilter = filterStatus ? filterStatus.value : '';

            const filtered = mockTasks.filter(task => {
                const matchSearch = task.title.toLowerCase().includes(searchTerm) || 
                                   task.assignee.toLowerCase().includes(searchTerm);
                const matchDept = !deptFilter || task.department === deptFilter;
                const matchStatus = !statusFilter || task.status === statusFilter;
                return matchSearch && matchDept && matchStatus;
            });

            renderTasks(filtered);
        }

        if (applyBtn) applyBtn.addEventListener('click', filterTasks);
        if (searchInput) searchInput.addEventListener('keyup', filterTasks);
        if (filterDept) filterDept.addEventListener('change', filterTasks);
        if (filterStatus) filterStatus.addEventListener('change', filterTasks);

        // ===== إضافة تكليف جديد =====
        const saveTaskBtn = document.getElementById('saveTaskBtn');
        if (saveTaskBtn) {
            saveTaskBtn.addEventListener('click', function() {
                const title = document.getElementById('taskTitle').value.trim();
                const dept = document.getElementById('taskDepartment').value;
                const assignee = document.getElementById('taskAssignee').value;
                const dueDate = document.getElementById('taskDueDate').value;

                if (!title || !dept || !assignee || !dueDate) {
                    alert('❌ يرجى ملء جميع الحقول المطلوبة');
                    return;
                }

                const newTask = {
                    id: mockTasks.length + 1,
                    title: title,
                    department: dept,
                    assignee: assignee,
                    due: dueDate,
                    status: 'قيد التنفيذ',
                    priority: document.getElementById('taskPriority').value
                };

                mockTasks.unshift(newTask);
                renderTasks(mockTasks);

                const modal = bootstrap.Modal.getInstance(document.getElementById('newTaskModal'));
                if (modal) modal.hide();
                document.getElementById('newTaskForm').reset();

                const successMsg = document.createElement('div');
                successMsg.className = 'alert alert-success alert-dismissible fade show mt-3';
                successMsg.innerHTML = `
                    <i class="fas fa-check-circle me-2"></i>
                    تم إنشاء التكليف "${title}" بنجاح
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                `;
                const container = document.querySelector('.main-content .d-flex.justify-content-between').parentNode;
                container.insertBefore(successMsg, container.querySelector('.card'));
                setTimeout(() => successMsg.remove(), 4000);
            });
        }
    }

    // ==========================================
    // 8. تحديد جميع الإشعارات كمقروءة
    // ==========================================
    const markAllReadBtn = document.getElementById('markAllRead');
    if (markAllReadBtn) {
        markAllReadBtn.addEventListener('click', function() {
            const badges = document.querySelectorAll('.list-group-item .badge');
            badges.forEach(badge => {
                if (badge.textContent.includes('جديد') || badge.textContent.includes('مهم')) {
                    badge.textContent = 'مقروء';
                    badge.className = 'badge bg-secondary rounded-pill';
                }
            });
            const notificationBadge = document.querySelector('.sidebar .nav-link .badge');
            if (notificationBadge) {
                notificationBadge.textContent = '0';
                notificationBadge.className = 'badge bg-secondary rounded-pill ms-2';
            }
            this.innerHTML = '<i class="fas fa-check me-1"></i> تم التحديد';
            this.disabled = true;
        });
    }

    // ==========================================
    // 9. تنبيه للروابط غير المكتملة
    // ==========================================
    const incompleteLinks = document.querySelectorAll('.sidebar .nav-link:not([href])');
    incompleteLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            alert('⏳ هذه الصفحة قيد التطوير');
        });
    });

    // ==========================================
    // 10. إشعار ترحيبي في Console
    // ==========================================
    console.log('🚀 نظام فريقي - الإصدار التجريبي V1.0');
    console.log('📋 المستخدم: أحمد محمد (مدير المكتب الفني)');
    console.log('🔥 Firebase متصل بنجاح!');

});